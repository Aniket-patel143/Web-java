package com.example;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class RegistrationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String course = request.getParameter("course");
        String email = request.getParameter("email");
        String Gender = request.getParameter("gender");

        String url = "jdbc:mysql://localhost:3306/registration_db";
        String dbUser = "root";
        String dbPassword = "aniket@143";
       try {
		Class.forName("com.mysql.cj.jdbc.Driver");
	} catch (ClassNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}

        try (Connection connection = DriverManager.getConnection(url, dbUser, dbPassword)) {
            String sql = "INSERT INTO users (username, password, course, email,gender) VALUES (?, ?, ? ,?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, username);
                statement.setString(2, password);
                statement.setString(3, course);
                statement.setString(4, email);
                statement.setString(5, Gender);

                int rowsInserted = statement.executeUpdate();
                if (rowsInserted > 0) {
                    response.getWriter().println("Registration successful!");
                } else {
                    response.getWriter().println("Registration failed.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().println("An error occurred.");
        }
    }
}
