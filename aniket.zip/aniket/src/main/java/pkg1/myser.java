package pkg1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class myser
 */
@WebServlet("/myser")
public class myser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public myser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		String s= request.getParameter("t1");
		String s1= request.getParameter("password");
		String s2= request.getParameter("rememberme");
		String s4= request.getParameter("t2");
		String s5= request.getParameter("t3");
		String s6= request.getParameter("Male");
		String s7= request.getParameter("Female");
		String s8= request.getParameter("course");
		pw.print(s);
		pw.print(s1);
		pw.print(s2);
		pw.print(s4);
		pw.print(s5);
		pw.print(s6);
		pw.print(s7);
		pw.print(s8);

		
		pw.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
