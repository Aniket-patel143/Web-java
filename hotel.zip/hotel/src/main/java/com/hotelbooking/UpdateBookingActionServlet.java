package com.hotelbooking;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/updateBookingAction")
public class UpdateBookingActionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String name = request.getParameter("name");
        String mobile_no = request.getParameter("mobile_no");
        String room_type = request.getParameter("room_type");
        String category = request.getParameter("category");

        String jdbcURL = "jdbc:mysql://128.66.203.247/msc3it21";
        String jdbcUsername = "msc3it21";
        String jdbcPassword = "sumo@123";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            String sql = "UPDATE bookings SET name=?, mobile_no=?, room_type=?, category=? WHERE id=?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, name);
            statement.setString(2, mobile_no);
            statement.setString(3, room_type);
            statement.setString(4, category);
            statement.setInt(5, id);
            statement.executeUpdate();

            PrintWriter out = response.getWriter();
            out.println("Booking Updated Successfully!");
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
